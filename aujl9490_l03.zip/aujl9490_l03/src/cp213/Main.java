package cp213;

import java.time.LocalDate;

/**
 * Tests the Student class.
 *
 * @author your name here
 * @version 2022-01-17
 */
public class Main {

    public static void main(String[] args) {
	final String line = "-".repeat(40);
	int id = 123456;
	String surname = "Brown";
	String forename = "David";
	LocalDate birthDate =  LocalDate.parse("1962-10-25");
	Student student = new Student(id, surname, forename, birthDate);
	System.out.println("New Student:");
	System.out.println(student);
	System.out.println(line);
	System.out.println("Test Getters");

	// call getters here
	System.out.println("forename:  " + student.getForename());
	System.out.println("surname:   " + student.getSurname());
	System.out.println("id:        " + student.getId());
	System.out.println("birthday:  " + student.getBirthDate());
	

	System.out.println(line);
	System.out.println("Test Setters");

	// call setters here
	student.setForename("Indu");
	student.setSurname("Aujla");
	student.setId(210311400);
	LocalDate InduBirthDate = LocalDate.parse("2003-03-04");
	student.setBirthDate(InduBirthDate);


	System.out.println("Updated Student:");
	System.out.println(student);
	System.out.println(line);
	System.out.println("Test compareTo");

	// create new Students - call comparisons here
	LocalDate TSwiftbirthDate = LocalDate.parse("1989-12-13");
	Student new_student = new Student(123456789, "Taylor", "Swift", TSwiftbirthDate);
	System.out.println("New Student:");
	System.out.println();
	System.out.println(new_student);

	System.out.println();
	int result = student.compareTo(new_student);
	System.out.println("Compare:  " + result);
    }

}
