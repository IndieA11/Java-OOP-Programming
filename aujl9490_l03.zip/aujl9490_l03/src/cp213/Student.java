package cp213;

import java.time.LocalDate;

/**
 * Student class definition.
 *
 * @author Indu Aujla 
 * @version 2022-10-06
 */
public class Student implements Comparable<Student> {

    // Attributes private variables 
    private LocalDate birthDate = null;
    private String forename = "";
    private int id = 0;
    private String surname = "";

    /**
     * Instantiates a Student object.
     *
     * @param id        student ID number
     * @param surname   student surname
     * @param forename  name of forename
     * @param birthDate birthDate in 'YYYY-MM-DD' format
     */
    public Student(final int id, final String surname, final String forename, final LocalDate birthDate) {
    
    //this refers to current object in student constructor 
    //set the paramaters of the student class 
	this.id = id;
	this.surname = surname;
	this.forename = forename;
	this.birthDate = birthDate;

	return;
    }

    /*
     * 
     *
     * @see java.lang.Object#toString() Creates a formatted string of student data.
     */
    @Override
    public String toString() {
		String string = "";
		
		//format elements of the student class into a string 
		//Grabs the Surname etc. from the current object 
		string += "Name:      " + getSurname() + ", " + getForename() + "\r\nID:        " + getId() + "\r\nBirthdate: "
			+ getBirthDate();

	return string;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(final Student target) {
    	
    	int result = 0;
    	if (target.surname.equals(getSurname())) {
    		//compare formnae to the target one 
    	    if (target.forename.equals(getForename())) {
    	    	
    	    //compare id to target id 
    		if (target.id > getId()) { //order of student ids 
    		    result = -1;
    		} else if (target.id < getId()) { //order of student ids 
    		    result = 1;
    		} else {
    		    result = 0;
    		}
    	    }

    	} else {
    	    int compare = getSurname().compareTo(target.surname);

    	    if (compare > 0) {
    		result = 1;
    	    }
    	    if (compare < 0) {
    		result = -1;
    	    }

    	}

    	return result;
    	
    	}
    	

    
// getters
    
    /**
     * 
     * Takes no parameters and returns proper attribute
     * @return
     */
    public LocalDate getBirthDate() {
	return this.birthDate;
    }

    public String getForename() {
	return this.forename;
    }

    public int getId() {
	return this.id;
    }

    public String getSurname() {
	return this.surname;
    }

    // setters
    /**
     * @param birthdate
     */
    public void setBirthDate(final LocalDate birthdate) {
	this.birthDate = birthdate;
    }

    /**
     * @param forename
     */
    public void setForename(final String forename) {
	this.forename = forename;
    }

    /**
     * @param id
     */
    public void setId(final int id) {
	this.id = id;
    }

    /**
     * @param surname
     */
    public void setSurname(final String surname) {
	this.surname = surname;
    }

}
